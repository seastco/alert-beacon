"""Auto-generated file, do not edit by hand. 94 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_94 = [NumberFormat(pattern='(\\d{2})(\\d)(\\d{6})', format='\\1 \\2 \\3', leading_digits_pattern=['[1-689]']), NumberFormat(pattern='(\\d{3})(\\d{6})', format='\\1 \\2', leading_digits_pattern=['[1-689]']), NumberFormat(pattern='(\\d{3})(\\d{3})(\\d{3})', format='\\1 \\2 \\3', leading_digits_pattern=['7'])]
